[![Gitter](https://img.shields.io/gitter/room/gitterHQ/gitter.svg)](https://gitter.im/lagom/lagom?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)[<img src="https://img.shields.io/travis/typesafehub/activator-lagom-java.svg"/>](https://travis-ci.org/typesafehub/activator-lagom-java)
# activator-lagom-java

A Lagom Java seed template for Lightbend Activator
